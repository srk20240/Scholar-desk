import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, FileText, File as FileIcon, Trash2, Send, BookOpen, Sparkles, Loader2, Info, Menu, X, Sun, Moon, Layers } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

type UploadedFile = {
  id: string;
  name: string;
  type: string;
  size: number;
  data: string; // base64 without prefix
};

type Message = {
  id: string;
  role: 'user' | 'model';
  text: string;
};

export default function App() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    { id: 'welcome', role: 'model', text: 'Welcome to your academic tutor. Please upload a document to begin our session.' }
  ]);
  const [input, setInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const processFiles = (fileList: FileList | null) => {
    if (!fileList) return;
    
    Array.from(fileList).forEach(file => {
      if (file.type === 'application/pdf' || file.name.endsWith('.md') || file.type === 'text/markdown') {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          const base64Data = result.split(',')[1];
          
          const newFile: UploadedFile = {
            id: Math.random().toString(36).substring(7),
            name: file.name,
            type: file.type || (file.name.endsWith('.md') ? 'text/markdown' : 'application/octet-stream'),
            size: file.size,
            data: base64Data
          };
          
          setFiles(prev => {
            const updated = [...prev, newFile];
            if (updated.length === 1) {
              setActiveFileId(newFile.id);
            }
            return updated;
          });
        };
        reader.readAsDataURL(file);
      } else {
        alert(`Unsupported file type: ${file.name}. Please upload PDF or Markdown files.`);
      }
    });
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    
    const newUserMsg: Message = { id: Date.now().toString(), role: 'user', text: userText };
    setMessages(prev => [...prev, newUserMsg]);
    setIsLoading(true);

    try {
      const activeFile = files.find(f => f.id === activeFileId);
      const parts: any[] = [];
      
      if (activeFile) {
        parts.push({
          inlineData: {
            mimeType: activeFile.type,
            data: activeFile.data
          }
        });
      }
      
      parts.push({ text: userText });

      const contents = messages.filter(m => m.id !== 'welcome').map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      contents.push({
        role: 'user',
        parts: parts
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: contents,
        config: {
          systemInstruction: "You are an academic tutor. You help the user understand the documents they provide. Be rigorous, clear, and helpful. Use markdown for formatting.",
        }
      });

      const modelMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text || 'No response.'
      };
      
      setMessages(prev => [...prev, modelMsg]);

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: '**Error:** Failed to get response from the tutor.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateSummary = async () => {
    if (files.length === 0) {
      alert("Please upload some files first.");
      return;
    }
    
    setIsSidebarOpen(false);
    
    const prompt = `Analyze all the files uploaded across every subject folder. Provide a Master Curriculum Summary that:
1. Lists each subject and its 3 most important themes.
2. Identifies 'Cross-Subject Links' (e.g., 'The math in Chapter 2 of Physics is also used in Calculus Section 4').
3. Creates a 1-page 'Cheat Sheet' that covers the high-level concepts for the entire semester.`;

    const newUserMsg: Message = { id: Date.now().toString(), role: 'user', text: "Generate Master Curriculum Summary" };
    setMessages(prev => [...prev, newUserMsg]);
    setIsLoading(true);

    try {
      const parts: any[] = [];
      
      files.forEach(file => {
        parts.push({
          inlineData: {
            mimeType: file.type,
            data: file.data
          }
        });
      });
      
      parts.push({ text: prompt });

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: [{ role: 'user', parts }],
        config: {
          systemInstruction: "You are an academic tutor. You help the user understand the documents they provide. Be rigorous, clear, and helpful. Use markdown for formatting.",
        }
      });

      const modelMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text || 'No response.'
      };
      
      setMessages(prev => [...prev, modelMsg]);

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: '**Error:** Failed to generate summary.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-zinc-50 dark:bg-[#0f0f11] text-zinc-800 dark:text-zinc-300 font-sans overflow-hidden transition-colors duration-200">
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Left Pane: Library */}
      <div className={`
        fixed md:static inset-y-0 left-0 z-50
        w-4/5 sm:w-80 md:w-1/3 md:min-w-[300px] md:max-w-[400px] 
        border-r border-zinc-200 dark:border-zinc-800 
        flex flex-col bg-white dark:bg-[#131315]
        transform transition-transform duration-300 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Sidebar Header */}
        <div className="p-4 md:p-6 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-amber-600 dark:text-amber-500" />
            <h1 className="text-xl font-serif text-zinc-900 dark:text-zinc-100 tracking-wide">Scholar's Desk</h1>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="md:hidden p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {/* Drag & Drop Area */}
        <div className="p-4">
          <div 
            className={`border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center transition-colors cursor-pointer min-h-[120px]
              ${isDragging ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10' : 'border-zinc-300 dark:border-zinc-700 hover:border-amber-500/50 hover:bg-zinc-50 dark:hover:bg-zinc-800/50'}`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); processFiles(e.dataTransfer.files); }}
            onClick={() => fileInputRef.current?.click()}
          >
            <UploadCloud className="w-8 h-8 text-zinc-400 dark:text-zinc-500 mb-3" />
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Drag & drop PDFs or Markdown</p>
            <p className="text-xs text-zinc-500 mt-1">or click to browse</p>
            <input type="file" className="hidden" ref={fileInputRef} multiple accept=".pdf,.md,text/markdown,application/pdf" onChange={(e) => processFiles(e.target.files)} />
          </div>
        </div>

        {/* Master Summary Button */}
        {files.length > 0 && (
          <div className="px-4 pb-2">
            <button
              onClick={handleGenerateSummary}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-amber-100 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 rounded-xl border border-amber-200 dark:border-amber-500/20 hover:bg-amber-200 dark:hover:bg-amber-500/20 transition-colors font-medium text-sm min-h-[44px]"
            >
              <Layers className="w-4 h-4" />
              Generate Master Summary
            </button>
          </div>
        )}

        {/* File List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3 px-2">Your Library</h2>
          {files.map(file => (
            <div 
              key={file.id}
              onClick={() => { setActiveFileId(file.id); setIsSidebarOpen(false); }}
              className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all border min-h-[44px]
                ${activeFileId === file.id 
                  ? 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/30 text-amber-700 dark:text-amber-400' 
                  : 'bg-zinc-50 dark:bg-zinc-800/30 border-transparent hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
            >
              {file.name.endsWith('.pdf') ? <FileText className="w-5 h-5 shrink-0" /> : <FileIcon className="w-5 h-5 shrink-0" />}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{file.name}</p>
                <p className="text-xs opacity-60">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <button 
                onClick={(e) => { 
                  e.stopPropagation(); 
                  setFiles(files.filter(f => f.id !== file.id)); 
                  if(activeFileId === file.id) setActiveFileId(null); 
                }}
                className="p-2 rounded-md hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 dark:text-zinc-500 hover:text-red-500 dark:hover:text-red-400 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                title="Remove file"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
          {files.length === 0 && (
            <div className="text-center p-6 text-zinc-500 dark:text-zinc-600 text-sm italic">
              Your library is empty.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 text-center">
          <p className="text-xs text-zinc-500 font-medium tracking-wide">
            Built by <span className="text-amber-600 dark:text-amber-500/80">Sreehari Tm</span>
          </p>
        </div>
      </div>

      {/* Right Pane: Chat Tutor */}
      <div className="flex-1 flex flex-col relative min-w-0">
        {/* Header */}
        <div className="h-16 md:h-20 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between px-4 md:px-8 bg-white/80 dark:bg-[#0f0f11]/80 backdrop-blur-sm z-10 shrink-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="md:hidden p-2 -ml-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-amber-100 dark:bg-amber-500/10 flex items-center justify-center border border-amber-200 dark:border-amber-500/20 shrink-0">
              <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-amber-600 dark:text-amber-500" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base md:text-lg font-serif text-zinc-900 dark:text-zinc-100 truncate">AI Tutor</h2>
              <p className="text-[10px] md:text-xs text-zinc-500 truncate">
                {activeFileId 
                  ? <span>Focusing on: <span className="text-amber-600 dark:text-amber-500/80">{files.find(f => f.id === activeFileId)?.name}</span></span>
                  : 'General knowledge mode'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4 shrink-0">
            {activeFileId && (
              <div className="hidden sm:flex items-center gap-2 text-xs text-amber-700 dark:text-amber-500/80 bg-amber-50 dark:bg-amber-500/10 px-3 py-1.5 rounded-full border border-amber-200 dark:border-amber-500/20">
                <Info className="w-3.5 h-3.5" />
                <span>Document context active</span>
              </div>
            )}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              title="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Chat History */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 scroll-smooth">
          {messages.map(msg => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[90%] md:max-w-[80%] rounded-2xl p-4 md:p-5 ${
                msg.role === 'user' 
                  ? 'bg-zinc-800 dark:bg-zinc-800 text-zinc-100 rounded-tr-sm' 
                  : 'bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-zinc-800 text-zinc-800 dark:text-zinc-300 rounded-tl-sm shadow-sm'
              }`}>
                {msg.role === 'model' ? (
                  <div className="prose prose-sm md:prose-base dark:prose-invert prose-amber max-w-none prose-p:leading-relaxed prose-pre:bg-zinc-50 dark:prose-pre:bg-zinc-900 prose-pre:border prose-pre:border-zinc-200 dark:prose-pre:border-zinc-800 prose-a:text-amber-600 dark:prose-a:text-amber-400 hover:prose-a:text-amber-500 dark:hover:prose-a:text-amber-300">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="whitespace-pre-wrap text-sm md:text-base">{msg.text}</p>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white dark:bg-[#18181b] border border-zinc-200 dark:border-zinc-800 rounded-2xl rounded-tl-sm p-4 md:p-5 flex items-center gap-3 text-zinc-500 dark:text-zinc-400 shadow-sm">
                <Loader2 className="w-5 h-5 animate-spin text-amber-600 dark:text-amber-500" />
                <span className="text-sm animate-pulse">Analyzing...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 bg-zinc-50 dark:bg-[#0f0f11] border-t border-zinc-200 dark:border-zinc-800 shrink-0">
          <div className="max-w-4xl mx-auto relative flex items-end gap-2 md:gap-3 bg-white dark:bg-[#18181b] border border-zinc-300 dark:border-zinc-800 rounded-2xl p-2 focus-within:border-amber-500/50 focus-within:ring-1 focus-within:ring-amber-500/50 transition-all shadow-sm">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                e.target.style.height = 'auto';
                e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={activeFileId ? `Ask about ${files.find(f => f.id === activeFileId)?.name}...` : "Ask a general question..."}
              className="flex-1 bg-transparent border-none focus:ring-0 resize-none max-h-48 min-h-[44px] p-3 text-zinc-900 dark:text-zinc-100 placeholder-zinc-500 dark:placeholder-zinc-600 outline-none text-sm md:text-base"
              rows={1}
              style={{ height: 'auto' }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-3 rounded-xl bg-amber-500 text-zinc-950 hover:bg-amber-400 disabled:opacity-50 disabled:hover:bg-amber-500 transition-colors shrink-0 mb-1 mr-1 min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <p className="text-center text-[10px] md:text-xs text-zinc-500 dark:text-zinc-600 mt-3 px-4">
            The tutor can make mistakes. Consider verifying important information.
          </p>
        </div>
      </div>
    </div>
  );
}
